class InvalidLanguageException(Exception):
    pass